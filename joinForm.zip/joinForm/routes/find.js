var express = require('express');
var router = express.Router();
var client = require('mongodb').MongoClient;

router.post('/',function(req,res,next){
	
	client.connect('mongodb://203.153.146.39/test', function(err,db){

		var result = "";

		var query = {};

		if (req.body.gridname != "")
		{
			query['input.Grid']=req.body.gridname;
		}
		if (req.body.umach != "")
		{
			query['input.Umach']=req.body.umach;
		}
		if (req.body.aoa != "")
		{
			query['input.AOA']=req.body.aoa;
		}
		if (req.body.re != "")
		{
			query['input.RE']=req.body.re;
		}
		if (req.body.ivisc != "")
		{
			query['input.IVISC']=req.body.ivisc;
		}
		if (req.body.rho_inf != "")
		{
			query['input.rho_inf']=req.body.rho_inf;
		}
		if (req.body.t_inf != "")
		{
			query['input.t_inf']=req.body.t_inf;
		}
		if (req.body.p_inf != "")
		{
			query['input.p_inf']=req.body.p_inf;
		}
		if (req.body.t_wall != "")
		{
			query['input.t_wall']=req.body.t_wall;
		}
		if (req.body.intensity != "")
		{
			query['input.intensity']=req.body.intensity;
		}
		if (req.body.f_func != "")
		{
			query['input.f_func']=req.body.f_func;
		}
		if (req.body.f_order != "")
		{
			query['input.f_order']=req.body.f_order;
		}
		if (req.body.limiter != "")
		{
			query['input.limiter']=req.body.limiter;
		}

		var cursor = db.collection("testDB1").find(query);

	
		cursor.each(function(err, items){
			res.render('resultForm',{items:items});
		})
	})
});


module.exports = router;
