var express = require('express');
var router = express.Router();
var client = require('mongodb').MongoClient;

router.get('/', function(req, res, next) {
  res.render('searchForm',{title:'Airfoil Simulation Data Search'});
});

module.exports = router;
