package loader;

import java.io.*;
import java.util.StringTokenizer;

public class test {
	public static void main(String[] args) throws IOException {
		/*BufferedReader in = new BufferedReader(new FileReader(args[0]+"\\kflow.inp"));
		String line;
		while ((line = in.readLine()) != null) {
			StringTokenizer st = new StringTokenizer(line);
			while (st.hasMoreTokens()) {
				String str = st.nextToken();
				System.out.println(str);
			}
		}*/
	}
}
