package loader;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.mongodb.BasicDBList;

import com.mongodb.BasicDBObject;
import com.mongodb.DB;
import com.mongodb.DBCollection;
import com.mongodb.DBObject;
import com.mongodb.MongoClient;
import com.mongodb.WriteConcern;

public class MakeJSONDocumentToMongoDB {
	public MakeJSONDocumentToMongoDB(String[] args) {
		// MongoDB insert
		MongoClient mongoClient = null;

		try {
			mongoClient = new MongoClient("localhost", 27017);
			System.out.println("success");
			
			// write permission
			WriteConcern w = new WriteConcern(1, 2000);
			mongoClient.setWriteConcern(w);

			// db connect
			DB db = mongoClient.getDB("test");

			// collection bring
			DBCollection coll = db.getCollection("testDB1");

			// data insert in testDB1 table
			DBObject doc_all = new BasicDBObject();

			DBObject doc_input = new BasicDBObject();
			doc_input.put("Grid", args[0]);
			doc_input.put("Umach", args[1]);
			doc_input.put("AOA", args[2]);
			doc_input.put("RE", args[3]);
			doc_input.put("IVISC", args[4]);
			doc_input.put("rho_inf", args[5]);
			doc_input.put("t_inf", args[6]);
			doc_input.put("p_inf", args[7]);
			doc_input.put("t_wall", args[8]);
			doc_input.put("intensity", args[9]);
			doc_input.put("f_func", args[10]);
			doc_input.put("f_order", args[11]);
			doc_input.put("liminter", args[12]);

			DBObject doc_output = new BasicDBObject();
			DBObject doc_aerodynamic = new BasicDBObject();
			doc_aerodynamic.put("Cl", args[13]);
			doc_aerodynamic.put("Cdt", args[14]);
			doc_aerodynamic.put("Cdp", args[15]);
			doc_aerodynamic.put("Cdf", args[16]);
			doc_aerodynamic.put("Cm", args[17]);
			doc_output.put("aerodynamic", doc_aerodynamic);
			
			
			DBObject doc_field = new BasicDBObject();
			doc_field.put("flo001", args[18]);
			doc_field.put("flo002", args[19]);
			doc_field.put("flo003", args[20]);
			doc_field.put("flo004", args[21]);
			doc_field.put("flo005", args[22]);
			doc_field.put("flo006", args[23]);
			doc_field.put("flo007", args[24]);
			doc_field.put("flo008", args[25]);
			doc_field.put("flo009", args[26]);
			doc_field.put("flo010", args[27]);
			doc_field.put("flo011", args[28]);
			doc_field.put("flo012", args[29]);
			doc_field.put("flo013", args[30]);
			doc_field.put("flo014", args[31]);
			doc_field.put("flo015", args[32]);
			doc_field.put("flo016", args[33]);
			doc_output.put("field", doc_field);
			
			/* list �� ���
			BasicDBList field = new BasicDBList();
			for (int i=18; i<34 ; i++)
				field.add(args[i]);
			doc_field.put("flo", field);
			doc_output.put("field_data", doc_field);
			*/
			
			
			DBObject doc_surface = new BasicDBObject();
			doc_surface.put("sur002", args[34]);
			doc_surface.put("sur003", args[35]);
			doc_surface.put("sur004", args[36]);
			doc_surface.put("sur005", args[37]);
			doc_surface.put("sur006", args[38]);
			doc_surface.put("sur007", args[39]);
			doc_output.put("surface", doc_surface);
			
			
			/* list �� ���
			BasicDBList surface = new BasicDBList();
			for (int i=34; i<40 ; i++)
				surface.add(args[i]);
			doc_surface.put("sur", surface);
			doc_output.put("surface_data", doc_surface);
			*/
			
			doc_all.put("simulator", "KFLOW");
			doc_all.put("input", doc_input);
			doc_all.put("output", doc_output);

			coll.insert(doc_all, null);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
